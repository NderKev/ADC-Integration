﻿

namespace Openchain.ADCGateway
{
    public class OutboundTransaction
    {
        public OutboundTransaction(string target, ByteString version, ByteString recordKey, long amount )
        {

            this.Target = target;
            this.Version = version;
            this.RecordKey = recordKey;
            this.Amount = amount;
            
            
        }

        public ByteString RecordKey { get; }

        public ByteString Version { get; }

        public long Amount { get; }

        public string Target { get; }
    }
}
