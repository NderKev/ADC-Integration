﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ADC.PaymentProtocol;
using Google.Protobuf;
using NBitcoin;

namespace Openchain.ADCGateway
{
    public class PaymentRequestManager
    {
        private readonly ulong dustValue = 1000;
        private readonly bool isMainNet;
        private BitcoinAddress destinationAddress;
        public Network network;
        /*public struct PaymentDetails {
            public string network;
            //bool isMainNet;
            public ulong Time;
            public ulong Expires;
            public string Memo;
           
        };

        public struct Output
        {
            public ulong Amount;
            //bool isMainNet;
            //public ulong Time;
           // public ulong Expires;
            public Google.Protobuf.ByteString Script ;
            public  ByteString [] Outputs;

        }; */
        public PaymentRequestManager(bool isMainNet, string destinationAddress)
        {
            this.isMainNet = isMainNet;
            this.destinationAddress = BitcoinAddress.Create(destinationAddress);

        }
        public ByteString GetPaymentRequest(string finalAccount, ulong amount)
        {
            PaymentDetails paymentDetails = new PaymentDetails();
            paymentDetails.Network = isMainNet ? "main" : "test";
            paymentDetails.Time = GetTimestamp(DateTime.UtcNow);
            paymentDetails.Expires = GetTimestamp(DateTime.UtcNow.AddHours(1));
            paymentDetails.Memo = $"Funding Openchain account {finalAccount}";

            Output paymentOutput = new Output();
            paymentOutput.Amount = amount;
            Network network = this.network;
            paymentOutput.Script = Google.Protobuf.ByteString.CopyFrom(NBitcoin.Script.Empty.GetDestinationAddress((network).ToByteString().ToArray()));

            Output dataOutput = new Output();
            dataOutput.Amount = dustValue;
            dataOutput.Script = Google.Protobuf.ByteString.CopyFrom(
                new[] { (byte)OpcodeType.OP_RETURN }.Concat(Op.GetPushOp(Encoding.UTF8.GetBytes("AX" + finalAccount)).ToBytes()).ToArray());

            paymentDetails.Outputs.Add(paymentOutput);
            paymentDetails.Outputs.Add(dataOutput);

          
             PaymentRequest request = new PaymentRequest();
            request.SerializedPaymentDetails = paymentDetails.ToByteString();
            request.PkiType = "none";

            return new ByteString(request.ToByteArray());
        }

        private static ulong GetTimestamp(DateTime date)
        {
            return (ulong)(date - new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
        }
    }
}
