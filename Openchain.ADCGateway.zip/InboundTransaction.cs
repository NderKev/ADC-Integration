﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Openchain.ADCGateway
{
    public class InboundTransaction
    {
        public InboundTransaction(string transactionHash, int outputIndex, string asset, string address, long amount)
        {
            this.TransactionHash = transactionHash;
            this.OutputIndex = outputIndex;
            this.Asset = asset;
            this.Address = address;
            this.Amount = amount;
            
        }

        public string TransactionHash { get; }

        public int OutputIndex { get; }

        public string Asset { get; }

        public long Amount { get; }

        public string Address { get; }
    }
}
